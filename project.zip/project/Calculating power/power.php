<!DOCTYPE HTML>
<HTML>
	<HEAD>
		<TITLE>POWER</TITLE>
	</HEAD>
	<BODY>
		<?php
			$n1 = $_POST["base"];
			$n2 = $_POST["pow"];
			if ($n2=="")
				$res = calcpow($n1);
			else
				$res = calcpow($n1,$n2);
			
			echo "The value of ".$n1."<sup>".$n2."</sup> is: ".$res;
			
			function calcpow($n1,$n2=3)
			{
				$res=1;
				for($i=0;$i<$n2;$i++)
				{
					$res=$res*$n1;
				}
				return $res;
			}
		?>
	</BODY>
</HTML>