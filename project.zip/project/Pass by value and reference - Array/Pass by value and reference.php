<!Doctype HTML>
<HTML>
	<head>
		<title>Pass by value and reference</title>
	</head>
	<body>
		<H1>Pass by value and pass by reference</h1>
		<?php
			$arr = Array(3,4,7,9,2);
			echo "<b>Pass by value<br/>The original array before passing it to the passbyvalue function is:</b> <br/>";
			print_r($arr);
			passbyvalue($arr);
			echo "<br/><b>Array after passing from passbyvalue function and when it is outside the function is:</b><br/>";
			print_r($arr);
			
			function passbyvalue($arr)
			{
				foreach ($arr as $k=>$v)
					$arr[$k] = $v * $v;
				echo "<br/><b>Array after passing from passbyvalue function and when it is within the function is:</b><br/>";
				print_r($arr);				
			}
			echo "<hr/>";
		
			echo "<b>Pass by reference<br/>The original array before passing it to the passbyref function is:</b> <br/>";
			print_r($arr);
			passbyref($arr);
			echo "<br/><b>Array after passing from passbyref function and when it is outside the function is:</b><br/>";
			print_r($arr);
			
			function passbyref(&$arr)
			{
				foreach ($arr as $k=>$v)
					$arr[$k] = $v * $v;
				echo "<br/><b>Array after passing from passbyref function and when it is within the function is:</b><br/>";
				print_r($arr);				
			}
		?>
	</body>
</HTML>