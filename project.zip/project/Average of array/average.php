<!Doctype HTML>
<HTML>
	<Head>
		<title>Calculating the average of array</title>
	</head>
	<body>
		<H1>Average of array in PHP</H1>
		<?php
			$sum = 0;
			$arr=array(21,24,34,54,75);
			foreach ($arr as $k=>$v)
				$sum = $sum + $v;
			
			echo "<b>The original array is: </b><br/>";
			print_r($arr);
			
			$avg = $sum/count($arr);
			echo "<br/><b>The average of all the elements of array is: </b>".$avg;
		?>
	</body>
</HTML>