function fetchdata(str)
{
	xrf = new XMLHttpRequest();
	
	let url="HTML_JS_PHP_XML.php?key="+str;
	url = url + "&ran="+Math.random();
	
	xrf.open("GET",url,true)
	xrf.send();
	
	xrf.onreadystatechange = function()
	{
		if(xrf.readyState==4 && xrf.status==200)
		{
			document.getElementById['display'].innerHTML = xrf.responseText;
		}
	}
}