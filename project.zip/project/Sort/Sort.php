<!DOCTYPE HTML>
<HTML>
	<HEAD>
		<TITLE>Sorting arrays in PHP</TITLE>
	</HEAD>
	<BODY>
		<H1>Sorting arrays</H1>
		<?php
			$arr["Ravi"]=23;
			$arr["Girish"]=26;
			$arr["Sandeep"]=22;
			$arr["Akash"]=20;
			$arr["Pratik"]=18;
			
			echo "<b>The Initial array is:</b> ";
			print_r($arr);
			echo "<hr>";
			$arrsize = count($arr);
			echo "<b>The number of elements in array is:</b> $arrsize\n";
			echo "<hr>";
			echo "<b>Array after sorting the data based on key value:</b> ";
			ksort($arr);
			print_r($arr);
			echo "<hr>";
			echo "<b>Array after sorting the data based on marks value:</b> ";
			sort($arr);
			print_r($arr);
			echo "<hr>";
			echo "<b>Array after sorting the data based on marks value using associative sort:</b> ";
			asort($arr);
			print_r($arr);
			echo "<hr>";
		?>
	</BODY>
</HTML>