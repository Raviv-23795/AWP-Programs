<!DOCTYPE HTML>
<HTML>
	<HEAD>
		<TITLE>Nested arrays in PHP</TITLE>
	</HEAD>
	<BODY>
		<H1>Nested arrays</H1>
		<?php
			$nested_array = Array("Raj"=>array("m"=>40,"s"=>50,"e"=>60),"Meena"=>array("m"=>50,"s"=>70,"e"=>45));
			//print_r($nested_array);
			
			echo "<br>";
			
			echo "<b>Display Nested array:</b> <br/>";
			foreach($nested_array as $k=>$v)
			{
				echo "$k $v=>";
				foreach($v as $nk=>$nv)
					echo "$nk=$nv";
			}
			echo "<hr>";
			
			$nested_array = Array("fname"=>"Ravi","lname"=>"Verma","marks"=>Array("SSC"=>88.36,"HSC"=>75.83,"BE"=>76.7));
			//print_r($nested_array);
			
			echo "<b>Displaya nested array along with other data types</b>: <br/>";
			foreach($nested_array as $k=>$v)
			{
				if(is_array($v))
				{
					echo "$k=>$v";
					foreach($v as $nk=>$nv)
						echo "$nk=>$nv";
				}
				else
				{
					echo "$k=>$v";
				}
				
			}	
		?>
	</BODY>
</HTML>