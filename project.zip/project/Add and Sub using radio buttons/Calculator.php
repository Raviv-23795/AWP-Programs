<!DOCTYPE HTML>
<HTML>
	<HEAD>
		<TITLE>Calculator</TITLE>
	</HEAD>
	<HEAD>
		<?php
			$n1 = $_POST["num1"];
			$n2 = $_POST["num2"];
			$addsub = $_POST["calc"];
			if ($addsub =="add")
			{
				$res = $n1 + $n2;
				echo "Addition of ".$_POST['num1']." and ".$_POST['num2']." is ".$res;
			}
			else
			{
				$res = $n1 - $n2;
				echo "Subtraction of ".$_POST['num1']." and ".$_POST['num2']." is ".$res;
			}
		?>
	</HEAD>
</HTML>