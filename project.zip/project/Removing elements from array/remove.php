<!DOCTYPE HTML>
<HTML>
	<HEAD>
		<TITLE>Removing elements from arrays in PHP</TITLE>
	</HEAD>
	<BODY>
		<H1>Deleting elements from arrays</H1>
		<?php
			$arr[0]="Ravi";
			$arr[1]="Girish";
			$arr[2]="Sandeep";
			$arr[3]="Akash";
			$arr[4]="Pratik";
			
			echo "<b>The original array is:</b> ";
			print_r($arr);
			echo "<hr>";
			
			echo "<b>Array after removing an element from it is:</b> ";
			unset($arr["3"]);
			print_r($arr);
			echo "<hr>";
			
			echo "<b>Array after resetting is:</b> ";
			$arr_reset = array_values($arr);
			print_r($arr_reset);
			echo "<hr>";
			
			unset($arr);
			//print_r($arr);
			echo "<b>Original array deleted hence cannot be displayed!</b> ";

			foreach($arr_reset as $key)
				unset($arr_reset[$key]);
				
			print_r($arr_reset);
		?>
	</BODY>
</HTML>