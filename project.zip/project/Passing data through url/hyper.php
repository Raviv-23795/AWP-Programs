<!doctype html>
<html>
	<head>
		<title>All in one form</title>
	</head>
	<body>
	<?php
		$a=$_REQUEST["num1"];
		$b=$_REQUEST["num2"];
		echo "<a href='submit1.php?n1=$a&n2=$b'>click here</a>";
		?>
	</body>
</html>
