<!doctype html>
<html>
	<head>
		<title>All in one form</title>
	</head>
	<body>
		<Form action="hyper.php" method="post">
			number 1:<input type="number" name="num1">
			number 2:<input type="number" name="num2">
			<input type="submit" value="calculate">
		</form>
	</body>
</html>
