<!doctype html>
<html>
	<head>
		<title>All in one form</title>
	</head>
	<body>
		<?php
		$c=$_REQUEST['n1']+$_REQUEST['n2'];
		echo $c;
		?>
	</body>
</html>
