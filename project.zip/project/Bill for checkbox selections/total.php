<!DOCTYPE HTML>
<HTML>
	<HEAD>
		<TITLE>TOTAL</TITLE>
	</HEAD>
	<BODY>
		<?php
			$cnt = count($_POST);
			$sum = 0;
			echo "<table border='1' cellpadding='20' cellspacing='0' height='250' width='500'>";
			echo "<th colspan='2'>Your Purchased</th>";
			foreach ($_POST as $k=>$v)
			{
				echo "<tr><td>$k</td><td>$v</td></tr>";
				$sum = $sum + $v;
			}
			echo "<tr><td>Total</td><td>$sum</td></tr>";
			echo "</table>";
		?>
	</BODY>
</HTML>