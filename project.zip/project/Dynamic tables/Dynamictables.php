<!DOCTYPE HTML>
<HTML>
	<HEAD>
		<TITLE>Dynamic tables</TITLE>
	</HEAD>
	<HEAD>
		<?php
			$row = $_POST["Row"];
			$col = $_POST["Column"];
			echo "<TABLE border='1' cellspacing='0' cellpadding='20' width='500px' height='250px'>";
			for($i=0;$i<$row;$i++)
			{
				echo "<tr>";
				for($j=0;$j<$col;$j++)
				{
					echo "<td> </td>";
				}
				echo "</tr>";
			}
			echo "</TABLE>";
		?>
	</HEAD>
</HTML>