<!doctype html>
<html>
	<head>
		<title>Sending Data through URL</title>
	</head>
	<body>
	<?php
		echo "<a href='submit.php?key=".$_REQUEST."'> Click Here to see your details </a>";
	?>
	</body>
</html>
