<!doctype html>
<?php 
	setcookie("Username",$_REQUEST['uname']);
	setcookie("Password",$_REQUEST['pass']);
?>
<html>
	<head>
		<title>Retriving data from form fields</title>
	</head>
	<body>
		<H1>And here are your details...</H1>
		<h3>Name: <?php echo $_REQUEST['fname']." ".$_REQUEST['lname'];?></h3>
		<h3>Education Details:<br/> <table border="1" cellpadding="0" cellspacing="0" width="300px" height="100px"><tr align="center"><b><td>Sr. No</td><td>Degree</td></b></tr><?php 
			foreach($_REQUEST['edu'] as $k=>$v)
			{?>
				<tr align="center"><td><?php echo $k+1;?></td><td><?php echo $v;?></td></tr>
			<?php }?>
			</table></h3>
			
		<h3>Gender: <?php echo $_REQUEST['mf'];?></h3>
		<h3>Email-ID: <?php echo $_REQUEST['email']?></h3>
		<h4>Address: <?php echo $_REQUEST['address']?></h4>
	</body>
</html>