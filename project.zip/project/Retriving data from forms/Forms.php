<!doctype html>
<html>
	<head>
		<title>All in one form</title>
	</head>
	<body>
		<fieldset align="center">
			<legend>Personal Data</legend>
			<form action="submit.php" method="post" enctype="multipart/form-data">
				<label title="Enter your first name">First Name:</label> <input type="text" name="fname" autofocus placeholder="Enter your first name" maxlength="15" required><br/><br/>
				<label title="Enter your last name">Last Name:</label> <input type="text" name="lname" maxlength="15" required><br/><br/>
				<label title="Select your education">Education:</label>
				<select name="edu[]" required multiple max="3">
					<option value="S.S.C">S.S.C</value>
					<option value="H.S.C">H.S.C</value>
					<option value="U.G">U.G</value>
					<option value="P.G">P.G</value>
				</select><br/><br/>
				<label title="select your Gender">Gender:</label> <input type="radio" name="mf" value="Male" required />Male<br/>
				<input type="radio" name="mf" value="Female" required />Female<br/><br/>
				<label title="Enter your Email">Email-ID:</label><input type="Email" name="email" /><br/><br/>
				<label title="Enter your Username">Username:</label> <input type="text" name="uname" maxlength="15" required><br/><br/>
				<label title="Enter your Password">Password:</label> <input type="password" name="pass" maxlength="15" required><br/><br/>
				<label title="Enter your Address">Address:</label> <textarea name="address" rows="5" cols="10" required ></textarea><br/><br/>
				<input type="submit" value="Submit"/>&nbsp;<input type="reset" value="Reset"/>
			</form>
		</fieldset>
	</body>
</html>

