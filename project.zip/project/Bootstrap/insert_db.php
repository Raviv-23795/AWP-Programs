<?php 
	$servername = "localhost";
	$sqlusername = "root";
	$sqlpassword = "";
	$databasename = "bootstrap";
	
	$connection = new mysqli($servername, $sqlusername, $sqlpassword, $databasename);
	/*if($connection->connect_error)
	{
		die("Connection failed: ".$connection->connect_error);
	}
	else
	{
		echo "Connection established";
	}*/
	
	$date = strval($dob);
	
	$insertdata = "INSERT INTO user_details (fname, lname, edu, gender, dob, upic, email, uname, password, address, phone, pin) VALUES ('$fname', '$lname', '$edu', '$gender', '$dob', '$upic', '$email', '$uname', '$password', '$address', '$phone', '$pin')";
	//********$insertdata = $connection->prepare("INSERT INTO user_details (fname, lname, edu, gender, dob, upic, email, uname, password, address, phone, pin) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
	//********$insertdata->bind_param("ssssssssssssi",$fname, $lname, $edu, $gender, $date, $upic, $email, $uname, $password, $address, $phone, $pin);
	//********$insertdata->execute();
	//********$insertdata->close();
	$connection->query($insertdata);
	
/*	if($connection->query($insertdata)===TRUE)
	{
		echo "Data successfully inserted in database";
	}
	else
	{
		echo "Error inserting data: ".$connection->error;
	}*/
	$connection->close();
?>