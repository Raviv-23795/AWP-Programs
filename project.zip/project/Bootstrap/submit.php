<!doctype html>
<?php 
	setcookie("Username",$_REQUEST['uname']);
	setcookie("Password",$_REQUEST['password']);
?>
<html>
	<head>
		<title>Retriving data from form fields</title>
		<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
		<style>
		.carousel-inner img {
			width: 100%;
			height: 100%;
		}
		</style>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">		
		<script src="js/bootstrap.min.js"></script>
	</head>
	<body>
	
		<!-- Capturing values from form fields -->
		<?php
			$fname = $_REQUEST['fname'];
			$lname = $_REQUEST['lname'];
			$education = $_REQUEST['edu'];
			$edu = implode(",",$education);
			$gender = $_REQUEST['gender'];
			$dob = $_REQUEST['dob'];
			$email = $_REQUEST['email'];
			$uname = $_REQUEST['uname'];
			$password = $_REQUEST['password'];
			$address = $_REQUEST['address'];
			$phone = $_REQUEST['phone'];
			$pin = $_REQUEST['pin'];
		?>
		
		<!-- Establishing connection with the database and creating tables -->
		<?php 
			require("creating_db.php");
			require("creating_table.php");
			require("insert_db.php");
			require("Signin.php");		
		?>
	</body>
</html>