<!doctype html>
<?php 
	setcookie("Username",$_REQUEST['uname']);
	setcookie("Password",$_REQUEST['password']);
?>
<html>
	<head>
		<title>Retriving data from form fields</title>
		<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
		<style>
		.carousel-inner img {
			width: 100%;
			height: 100%;
		}
		</style>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">		
		<script src="js/bootstrap.min.js"></script>
	</head>
	<body>
	
		<!-- Capturing values from form fields -->
		<?php
			$fname = $_REQUEST['fname'];
			$lname = $_REQUEST['lname'];
			$education = $_REQUEST['edu'];
			$edu = implode(",",$education);
			$gender = $_REQUEST['gender'];
			$dob = $_REQUEST['dob'];
			$email = $_REQUEST['email'];
			$uname = $_REQUEST['uname'];
			$password = $_REQUEST['password'];
			$address = $_REQUEST['address'];
			$phone = $_REQUEST['phone'];
			$pin = $_REQUEST['pin'];
		?>
		
		<!-- Establishing connection with the database and creating tables -->
		<?php 
/*			require("creating_db.php");
			require("creating_table.php");*/
			require("insert_db.php");
		?>
		
		<?php require("Signin.php");
		
		/*
		<H1>And here are your details...</H1>
		<h3>Name:<?php echo $fname." ".$lname;?></h3>
		<h3>Education Details:<br/> <table border="1" cellpadding="0" cellspacing="0" width="300px" height="100px"><tr align="center"><b><td>Sr. No</td><td>Degree</td></b></tr><?php 
			foreach($_REQUEST['edu'] as $k=>$v)
			{?>
				<tr align="center"><td><?php echo $k+1;?></td><td><?php echo $v;?></td></tr>
			<?php }?>
			</table></h3>
			
		<h3>Gender: <?php echo $gender;?></h3>
		<h3>Date of birth: <?php echo $dob;?></h3>
		<h3>Email-ID: <?php echo $email;?></h3>
		<h3>Mobile No.: <?php echo $phone;?></h3>
		<h3>Address: <?php echo $address." Pincode: ".$pin;?></h3>		
		*/
		?>
	</body>
</html>