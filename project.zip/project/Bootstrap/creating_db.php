		<?php
			$servername = "localhost";
			$sqlusername = "root";
			$sqlpassword = "root";
			
			$connection = new mysqli($servername, $sqlusername, $sqlpassword);
			/*if($connection->connect_error)
			{
				die("Connection failed: ".$connection->connect_error);
			}
			else
			{
				echo "Connection establised";
			}*/
			
			$createdb = "CREATE DATABASE bootstrap";
			$connection->query($createdb);
			/*if ($connection->query($createdb)===TRUE)
			{
				echo "Database created.";
			}
			else
			{
				echo "Error creating database: ".$connection->error;
			}*/
		?>