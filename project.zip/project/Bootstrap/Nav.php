		<hr>
		<nav class="row">
			<div class="col-sm-2">
				<a href="index1.php"><h3 align="center">Home</h3></a>
			</div>
			<div class="col-sm-2">
				<a href="Signin.php"><h3 align="center">Login</h3></a>
			</div>
			<div class="col-sm-2">
				<a href="signup.php"><h3 align="center">Register</h3></a>
			</div>
			<?php Session_start();?>
			<?php if(isset($_SESSION['Username']))
			{
			?>
				<div class="col-sm-2">
					<a href="display.php"><h3 align="center">Display</h3></a>
				</div>
			<?php
			}
			else
			{
			?>
				<div class="col-sm-2 nav-link disabled">
					<a href="display.php"><h3 align="center">Display</h3></a>
				</div>
			<?php
			}
			?>
			<?php if(isset($_SESSION['Username']))
			{
			?>
				<div class="col-sm-2">
					<a href="logout.php"><h3 align="center">Logout</h3></a>
				</div>
			<?php
			}
			else
			{
			?>
				<div class="col-sm-2 nav-link disabled">
					<a href="logout.php"><h3 align="center">Logout</h3></a>
				</div>
			<?php
			}
			?>
			<div class="col-sm-2">
				<a href="Contact.php"><h3 align="center">Contact us</h3></a>
			</div>
		</nav>
		<hr>