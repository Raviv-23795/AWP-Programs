<!DOCTYPE HTML>
<Html>
	<head>
		<title>Display</title>
		<link rel="stylesheet" href="css/bootstrap.css">
		<style>
			.detailtitle
			{
				font-weight:bold;
				color: #6f42c1;
				font-size:25px;
				display: inline;
			}
			.detailvalue
			{
				font-size:20px;
				color: black;
				display: inline;
			}
			.detailhead
			{
				margin-left: 80px;
				line-height: 2;
			}
		</style>
	</head>
	<body>
		<header><h1 align="center">Details</h1></header>
		<?php require("nav.php");
			$servername = "localhost";
			$sqlusername = "root";
			$sqlpassword = "root";
			$databasename = "bootstrap";
			$user = $_SESSION['Username'];
			
			$connect = new mysqli($servername, $sqlusername, $sqlpassword, $databasename);
			$displayrec = "SELECT * FROM user_details where uname='$user'";
			
			$details = $connect->query($displayrec);
			if($details->num_rows>0)
			{
				while($row = $details->fetch_assoc())
				{
					?>
						
						<div class="detailhead">
							<div class="detailtitle">ID Number: </div><div class="detailvalue"><?php echo $row['id'];?></div><br/>
							<div class="detailtitle">Name: </div><div class="detailvalue"><?php echo $row['fname']." ".$row['lname'];?></div><br/>
							<div class="detailtitle">Eduction: </div><div class="detailvalue"><?php echo $row['edu'];?></div><br/>
							<div class="detailtitle">Gender: </div><div class="detailvalue"><?php echo $row['gender'];?></div><br/>
							<div class="detailtitle">Date of birth: </div><div class="detailvalue"><?php echo $row['dob'];?></div><br/>
							<div class="detailtitle">Email: </div><div class="detailvalue"><?php echo $row['email'];?></div><br/>
							<div class="detailtitle">Address: </div><div class="detailvalue"><?php echo $row['address'];?></div><br/>
							<div class="detailtitle">Pincode: </div><div class="detailvalue"><?php echo $row['pin'];?></div><br/>
							<div class="detailtitle">Contact: </div><div class="detailvalue"><?php echo $row['phone'];?></div>
						</div>
					<?php
				}
			}
		?>
		
		<?php require("footer.html");?>
	</body>
</html>