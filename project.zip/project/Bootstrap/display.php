<!DOCTYPE HTML>
<Html>
	<head>
		<title>Sign In</title>
		<link rel="stylesheet" href="css/bootstrap.css">
	</head>
	<body>
		<header><h1 align="center">Login</h1></header>
		<?php require("nav.html");?>
		<h1 align="center">Welcome to the tutorial for bootstrap</h1>
		<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
		<?php require("footer.html");?>
	</body>
</html>