<!DOCTYPE HTML>
<html>
	<head>
		<title>Register</title>
		<link rel="stylesheet" href="css/bootstrap.css">
	</head>
	<body>
		<header><h1 align="center">Get Registered</h1></header>
		<hr>
		<?php require("nav.php");?>
		<hr>
		<form action="submit.php" method="post" enctype="multipart/form-data" style="margin-left: 80px">
			<label for="Enter your First name">Firstname: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label><input type="text" name="fname" required><br/><br/>
			<label for="Enter your last name">Lastname: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label><input type="text" name="lname" required><br/><br/>
			<label title="Select your education">Education: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
				<select name="edu[]" required multiple max="3">
					<option value="S.S.C">S.S.C</value>
					<option value="H.S.C">H.S.C</value>
					<option value="U.G">U.G</value>
					<option value="P.G">P.G</value>
				</select><br/><br/>
			<label title="select your Gender">Gender: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
			<input type="radio" name="gender" value="Male" required />Male
			<input type="radio" name="gender" value="Female" required />Female<br/><br/>
			<label for="What's your date of birth?">Date of Birth: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label><input type="date" name="dob" required max="2020-02-18"><br/><br/>
			<label for="What's your email ID?">Email ID: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label><input type="email" name="email" required><br/><br/>
			<label title="Enter your Username">Username: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label> <input type="text" name="uname" maxlength="15" required><br/><br/>
			<label for="Enter a strong password">Password: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label><input type="password" name="password" required maxlength="15" pattern="[a-zA-Z0-9@#$%^&*]{8,}"><br/><br/>
			<label for="Enter your mobile number">Mobile: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label><input type="text" name="phone" maxlength="10" required pattern="[0-9]{10}"><br/><br/>
			<label for="Enter your address">Address: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label><textarea name="address" required cols="50" rows="3"></textarea><br/><br/>
			<label for="Enter your pincode">Pin code: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label><input type="text" name="pin" maxlength="6" required pattern="[0-9]{6}"><br/><br/>
			<center><input type="submit" value="Submit" >&nbsp;&nbsp;<input type="reset" value="Reset"></center><br/>
		</form>
		<?php require("footer.html");?>
	</body>
</html>