		<?php 
			/*Creating database*/
			$servername = "localhost";
			$sqlusername = "root";
			$sqlpassword = "root";
			$databasename = "bootstrap";
			
			$connection = new mysqli($servername, $sqlusername, $sqlpassword, $databasename);
			/*if($connection->connect_error)
			{
				die("Connection failed: ".$connection->connect_error);
			}
			else
			{
				echo "Connection establised";
			}*/

			/*Creating table*/
			$createtable = "CREATE TABLE user_details (id INT(12) UNSIGNED AUTO_INCREMENT PRIMARY KEY,fname VARCHAR(20) NOT NULL,lname VARCHAR(20) NOT NULL,edu VARCHAR(30) NOT NULL,gender VARCHAR(10) NOT NULL,dob DATE NOT NULL,email VARCHAR(50) NOT NULL,uname VARCHAR(20) NOT NULL,password VARCHAR(20) NOT NULL,address  VARCHAR(100) NOT NULL,phone  BIGINT NOT NULL,pin  INT NOT NULL)";
			$connection->query($createtable);
			/*if ($connection->query($createtable)===TRUE)
			{
				echo "Table created.";
			}
			else
			{
				echo "Error creating database: ".$connection->error;
			}*/
			$connection->close();
		?>