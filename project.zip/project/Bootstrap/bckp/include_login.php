<fieldset>
	<header><h1 align="center">Login</h1></header>
	<form action="check_login.php" method="POST" onsubmit="return true" autocomplete="off" style="margin-left: 80px">
		<Label for="Enter your User ID">User ID: &nbsp;&nbsp;&nbsp;&nbsp;</label>
		<input type="text" name="uid" required><br/><br/>
		<Label for="Enter your password">Password: &nbsp;</label>
		<input type="password" name="password" required maxlength="15" pattern="[a-zA-z0-9@]{8,15}"><br/>
		<input type="hidden" name="err" value="1"/>
		<center><input type="submit" value="Submit">&nbsp;&nbsp;<input type="reset" value="Reset"></center><br/>
		<a href="signup.php" target="_blank">Signup</a>
	</form>
</fieldset>