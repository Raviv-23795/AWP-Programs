<!DOCTYPE HTML>
<Html>
	<head>
		<title>Sign In</title>
		<link rel="stylesheet" href="css/bootstrap.css">
	</head>
	<body>
		<header><h1 align="center">Login</h1></header>
		<?php
			require("nav.html");
		
			if (isset($_REQUEST['err']))
			{
				check_data();
				if(count($errormsg)!=0)
				{
					global $errormsg;
					echo $errormsg."<br/>";
					show_form();
				}
				else
					header("Location:display.php");
			}
			else
				show_form();
			require("footer.html");
			
			function show_form(){
		?>
			<fieldset>
				<header><h1 align="center">Login</h1></header>
				<form method="POST" action="<?php echo $_SERVER['PHP_SELF'];?>" onsubmit="return true" autocomplete="off" style="margin-left: 80px">
					<Label for="Enter your User ID">User ID: &nbsp;&nbsp;&nbsp;&nbsp;</label>
					<input type="text" name="uid" required><br/><br/>
					<Label for="Enter your password">Password: &nbsp;</label>
					<input type="password" name="password" required maxlength="15" pattern="[a-zA-z0-9@]{8,15}"><br/>
					<input type="hidden" name="err" value="1"/>
					<center><input type="submit" value="Submit">&nbsp;&nbsp;<input type="reset" value="Reset"></center><br/>
					<a href="signup.php" target="_blank">Signup</a>
				</form>
			</fieldset>
		<?php
			function check_data(){
				$uid = $_REQUEST['uid'];
				$password = $_REQUEST['password'];
				
				$servername = "localhost";
				$sqlusername = "root";
				$sqlpassword = "";
				$databasename = "bootstrap";
				
				$connection = new mysqli($servername, $sqlusername, $sqlpassword, $databasename);
				
				$retrivedata = "SELECT uname, password from user_details where uname='$uid' AND password='$password'";
				$result = $connection->query($retrivedata);
				
				if($result->num_rows<=0)
				{
					$retrivedata = "SELECT uname, password from user_details where uname='$uid'";
					$result = $connection->query($retrivedata);
					
					global $errormsg;
					if($result->num_rows>0)
						$errormsg = "<font color='red'>Please enter valid username or password!</font>";
					else
						$errormsg = "<font color='red'>The username does not exist. Please get registered before loging in!</font>";
				}
				$connection->close();}
		?>
	</body>
</html>