<!Doctype HTML>
<HTML>
	<HEAD>
		<TITLE>Login</TITLE>
	</HEAD>
	<BODY>
		<?php
			$uid = $_REQUEST['uid'];
			$password = $_REQUEST['password'];
			
			$servername = "localhost";
			$sqlusername = "root";
			$sqlpassword = "";
			$databasename = "bootstrap";
			
			$connection = new mysqli($servername, $sqlusername, $sqlpassword, $databasename);
			/*if ($connection->connect_error)
			{
				die("Connection failed");
			}
			else
			{
				echo "Connection established";
			}*/
			
			$retrivedata = "SELECT uname, password from user_details where uname='$uid' AND password='$password'";
			$result = $connection->query($retrivedata);
			
			if($result->num_rows>0)
			{
				echo "welcome";
			}
			else
			{
				$retrivedata = "SELECT uname, password from user_details where uname='$uid'";
				$result = $connection->query($retrivedata);
				if($result->num_rows>0)
					$errormsg = echo "Please enter valid username or password!";
				else
					echo "The username does not exist. Please get registered before loging in!";
				Header("Location:Signin.php");
			}
		?>
	</BODY>
</HTML>