<!DOCTYPE HTML>
<html>
	<head>
		<title>Contact Us</title>
		<link rel="stylesheet" href="css/bootstrap.css">
	</head>
	
	<body>
		<header><h1 align="center">Contact Us</h1></header>
		<?php require("nav.php");?>
		
		<div>
			<h2 style="margin-left: 80px">Our offices at...</h2>
			<br/>
			  <table border="1" style="margin-left: 80px">
				<thead>
				  <tr>
					<th>Office</th>
					<th>Address</th>
					<th>Phone</th>
				  </tr>
				</thead>
				<tbody>
				  <tr>
					<td>Texas Office</td>
					<td>1800 Preston Park Boulevard, Suite 115, Plano, TX 75093.</td>
					<td>(469) 925-0235</td>
				  </tr>
				  <tr>
					<td>New York Office</td>
					<td>300 East 59th Street, #1902, New York 10022</td>
					<td>(646) 524-7676</td>
				  </tr>
				  <tr>
					<td>Chicago Office</td>
					<td>O’Hare Atrium Office Plaza, 2860 River Road, Suite 155, Des Plaines, IL 60018</td>
					<td>(847) 813-7994 / (847) 813-7992</td>
				  </tr>
				  <tr>
					<td>Bay Area Office</td>
					<td>Parkway Plaza, Suite 315, 4677 Old Ironsides Drive, Santa Clara, CA 95054</td>
					<td>(408) 454-3340</td>
				  </tr>
				  <tr>
					<td>London Office</td>
					<td>250 Gander Green Lane, North Cheam, Surrey, SM3 9QF</td>
					<td>+44 203-564-2800</td>
				  </tr>
				  <tr>
					<td>Melbourne Office</td>
					<td>Hub Southern Cross, 696 Bourke St, Melbourne</td>
					<td>+61 1800870433</td>
				  </tr>
				  <tr>
					<td>Dadar Office</td>
					<td>31st Floor, Sunshine Tower, Senapati Bapat Marg, Dadar (West), Mumbai 400013</td>
					<td>+91 22 6652 7300</td>
				  </tr>
				</tbody>
			  </table>
		</div>
		<?php require("footer.html");?>
	</body>
</html>