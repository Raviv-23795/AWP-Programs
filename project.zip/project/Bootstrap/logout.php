<!DOCTYPE HTML>
<?php
	Session_start();
	session_unset();
	session_destroy();
?>
<Html>
	<head>
		<title>Sign In</title>
		<link rel="stylesheet" href="css/bootstrap.css">
	</head>
	<body>
		<header><h1 align="center">Login</h1></header>
		<?php require("nav.php");?>
		<h2>You've successfully logged out...</h2>
		<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
		<?php require("footer.html");?>
	</body>
</html>